Run A_regression for part A
Run B_Bayesian for part B
If some plots come, close them to advance the program
