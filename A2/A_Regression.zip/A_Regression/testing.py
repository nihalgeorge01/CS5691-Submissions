import numpy as np
import matplotlib.pyplot as plt

x_train,y_train = np.loadtxt("./Data/1D/1d_team_29_train.txt").T
x_dev,y_dev = np.loadtxt("./Data/1D/1d_team_29_dev.txt").T

plt.figure()
plt.scatter(x_train,y_train)
plt.title("Data Values")
plt.xlabel("x")
plt.ylabel("y")
plt.savefig("Data.png")
plt.show()

# Regression Function
# regul=0 for normal Least Squares Linear Regression
# regul>0 for Ridge Regression

def ls_regr(x,y,order,regul=0):
    x = np.asarray(x)
    y = np.asarray(y)
    phi = np.asarray([x**i for i in range(order+1)]).T
    phiT_phi_inv = np.linalg.inv(phi.T @ phi + np.diag([regul]*(order+1)))
    coeffs = phiT_phi_inv @ phi.T @ y

    return coeffs[::-1]

def plotter(x,y,order,regul=0,title=""):
    plotrange = np.linspace(0,5,1000)
    wid = len(x)
    coeffs = ls_regr(x,y,order=order,regul=regul)
    poly = np.poly1d(coeffs)
    plt.figure()
    plt.scatter(x,y)
    plt.plot(plotrange,poly(plotrange),'r')
    if title=="":
        plt.title(f'{order} degree polynomial fit')
    else:
        plt.title(title)
    plt.xlabel('x')
    plt.ylabel('y')
    plt.savefig(f'./Plots/poly{order}_{regul}_{wid}.png')
    #plt.show()
    plt.close()

plotrange = np.linspace(0,5,1000)

# Least Squares Regression (no Regularization)

"""
for i in [0,1,5,7,10]:
    for j in [10,20,50,100,200]:
        myrange = np.random.choice(range(0,200),size=(j,)) # choose j samples out of the range 0-199
        x_in = x_train[myrange] # sample the x values at those indices
        y_in = y_train[myrange] # sample the y values at those indices
        plotter(x_in,y_in,i)    # plot them!
"""

# Ridge Regression (Regularization Parameter non-zero)

for i in [0,1,5,7,10]:
    for j in np.logspace(-9,0,10):
        plotter(x_train,y_train,i,j)    # plot them for different regularization parameters

# Scatter Plot of best Performing Model vs Ground Truth

# Training set
plt.figure()
c10 = ls_regr(x_train,y_train,10,1e-5)
p10 = np.poly1d(c10)
plt.title(r"Model Output vs Target Output on Order 10 model with $\lambda = 10^{-5}$")
plt.xlabel("Target Output on Training Set")
plt.ylabel("Predicted Output on Training Set")
plt.scatter(y_train,p10(np.linspace(0,5,200)))
plt.show()

# Dev Set
plt.figure()
c10_d = ls_regr(x_dev,y_dev,10,1e-5)
p10_d = np.poly1d(c10_d)
plt.title(r"Model Output vs Target Output on Order 10 model with $\lambda = 10^{-5}$")
plt.xlabel("Target Output on Dev Set")
plt.ylabel("Predicted Output on Dev Set")
plt.scatter(y_train,p10_d(np.linspace(0,5,200)))
plt.show()

# Errors

err = 0.5 * np.sum((p10_d(np.linspace(0,5,200)) - y_train)**2)



def ls_regr_2D(x1,x2,y,order,regul=0):
    x1 = np.asarray(x1)
    x2 = np.asarray(x2)
    y = np.asarray(y)
    phi = np.vstack(([x1**i for i in range(order+1)],[x2**i for i in range(order+1)])).T
    phiT_phi_inv = np.linalg.inv(phi.T @ phi + np.diag([regul]*2*(order+1)))
    coeffs = phiT_phi_inv @ phi.T @ y
    return coeffs[::-1]

def plotter2D(x1,x2,y,order,regul):
    coeffs = ls_regr_2D(x1,x2,y,order=order,regul=regul)
    poly = np.poly1d(coeffs)
    
    fig = plt.figure(figsize=(11,8))
    ax = fig.add_subplot(2, 2, 1, projection='3d')
    ax.plot_surface(x1, x2, y, color="blue")
    ax.scatter(x1,x2,poly(np.vstack((x1,x2))))

x1_train_2d,x2_train_2d,y_train_2d = np.loadtxt("./Data/2D/2d_team_29_train.txt").T
x1_dev_2d,x2_dev_2d,y_dev_2d = np.loadtxt("./Data/2D/2d_team_29_dev.txt").T

plotter2D(x1_train_2d,x2_train_2d,y_train_2d,6,0)